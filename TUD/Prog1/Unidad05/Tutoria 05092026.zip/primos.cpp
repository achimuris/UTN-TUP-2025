#include <iostream>
#include <cstdio>
#include <string>
#include <cctype>
#include <algorithm> 


using namespace std;

#include <iostream>

using namespace std;

int main()
{
    int numero;
    bool esPrimo = true;

    cout << "Ingrese un numero para saber si es primo o no: ";
    cin >> numero;

    for (int i = 2; i < numero; i++)
    {
        if (numero % i == 0)
        {
            esPrimo = false;

            cout << "El numero " << numero
                 << " es divisible por " << i << endl;

            break;
        }
    }

    if (esPrimo)
    {
        cout << "El numero " << numero << " es primo" << endl;
    }
    else
    {
        cout << "El numero " << numero << " NO es primo" << endl;
    }

    return 0;
}